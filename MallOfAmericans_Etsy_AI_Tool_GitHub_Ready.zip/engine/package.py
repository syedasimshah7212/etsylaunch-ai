"""Truthful manifests, media QC and separate buyer/seller ZIPs."""
from pathlib import Path
import json
import csv
import subprocess
import zipfile
import fitz
from PIL import Image

IMAGE_NAMES=['01_hero.jpg','02_whats_included.jpg','03_benefit.jpg','04_inside_pages.jpg','05_workflow.jpg','06_format.jpg',
             '07_details.jpg','08_lifestyle.jpg','09_value.jpg','10_final_details.jpg']
VIDEO_NAMES=['01_product_overview.mp4','02_inside_the_product.mp4']


def probe_video(p):
    proc=subprocess.run(['ffprobe','-v','error','-select_streams','v:0',
        '-show_entries','stream=width,height:format=duration', '-of','json',str(p)],capture_output=True,text=True,timeout=15,check=True)
    js=json.loads(proc.stdout)
    return {'duration':round(float(js['format']['duration']),2),'width':int(js['streams'][0]['width']), 'height':int(js['streams'][0]['height'])}


def check_assets(root,meta):
    root=Path(root);files=[];issues=[]
    for relative in [f'02_Buyer_Downloads/{name}' for name in meta['files']]+[f'03_Etsy_Mockups/{name}' for name in IMAGE_NAMES]+[f'04_Etsy_Videos/{name}' for name in VIDEO_NAMES]:
        p=root/relative
        entry={'file':relative,'status':'CREATED' if p.is_file() and p.stat().st_size>0 else 'MISSING'}
        if entry['status']=='MISSING':issues.append(f'MISSING: {relative}')
        else:
            try:
                entry['bytes']=p.stat().st_size
                if p.suffix.lower()=='.jpg':
                    with Image.open(p) as image:
                        entry['dimensions']=list(image.size)
                        if min(image.size)<1800:raise ValueError('Image too small')
                elif p.suffix.lower()=='.mp4':
                    entry.update(probe_video(p))
                    if not 14.8<=entry['duration']<=15.2 or min(entry['width'],entry['height'])<1080:raise ValueError('Duration/resolution mismatch')
                elif p.suffix.lower()=='.pdf':
                    with fitz.open(p) as doc:entry['pages']=len(doc)
                    if entry['pages']!=meta['pages']:raise ValueError('PDF page count mismatch')
                entry['status']='VERIFIED'
            except Exception as exc:
                entry['status']='FAILED_QA';issues.append(f'{relative}: {exc}')
        files.append(entry)
    return {'complete':not issues,'files':files,'issues':issues}


def make_zip(source_folder, dest, exclude_dirs=()):
    src=Path(source_folder);dest=Path(dest)
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(src.rglob('*')):
            if not p.is_file() or any(x in p.relative_to(src).parts for x in exclude_dirs):continue
            z.write(p,p.relative_to(src))
    with zipfile.ZipFile(dest) as z:
        bad=z.testzip()
        if bad:raise ValueError(f'Corrupt ZIP entry: {bad}')
    return dest


def make_packages(root,output_base,metadata,research_report=None):
    root=Path(root);base=Path(output_base);base.mkdir(parents=True,exist_ok=True)
    qa=check_assets(root,metadata)
    qadir=root/'06_QA';qadir.mkdir(exist_ok=True)
    (qadir/'Deliverable_Manifest.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
    (qadir/'COMPLIANCE_CHECK.txt').write_text('PRE-PUBLISH CHECKLIST\n'
    '1. Confirm Etsy current seller and originality rules directly.\n'
    '2. Disclose AI assistance in the listing if applicable.\n'
    '3. Review trademarks, third-party assets, licensing and claims.\n'
    '4. Inspect all files manually; keep previews true to included pages.\n'
    '5. Confirm media count and dimensions in your actual Etsy listing interface.\n'
    '6. Never describe search snippets as full public competitor descriptions.\n'
    '7. Do not claim guaranteed sales, ranking or proven low competition.\n',encoding='utf-8')
    if research_report is not None:
        folder=root/'01_Research';folder.mkdir(exist_ok=True)
        (folder/'Research_Data.json').write_text(json.dumps(research_report,indent=2,ensure_ascii=False),encoding='utf-8')
        comps=research_report.get('competitors',[])
        with (folder/'Top_5_Competitors.csv').open('w',encoding='utf-8',newline='') as f:
            cols=['title','url','snippet','checked','source_type','user_observed_price','seller_description_notes','seller_notes_provenance']
            writer=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore')
            writer.writeheader();writer.writerows(comps)
        report=['# Research & evidence audit','',
                f"Public listing references returned: {len(comps)} / 5 requested.",
                'Private tags, actual item revenue, precise individual listing sales and search volume are unavailable from public snippets.',
                'Seller-added notes, if any, are not independently verified by this app.',
                '', '## Opportunities (subjective directional scoring, NOT verified demand)']
        for idea in research_report.get('opportunities',[]):
            report.append(f"- {idea['name']} | score {idea['weighted_score']}/5 | {idea['evidence_status']}")
        report.extend(['','## Competitor evidence'])
        for i,c in enumerate(comps,1):
            report.extend([f"### {i}. {c.get('title','Unknown title')}",
                           f"URL: {c.get('url','')}",
                           f"Checked: {c.get('checked','')}",
                           f"Public search snippet: {c.get('snippet','')}",
                           f"Seller-noted visible price: {c.get('user_observed_price','Unverified')}",
                           f"Seller description observations: {c.get('seller_description_notes','Not provided')}",''])
        if not comps: report.append('No competitor listings independently verified. Do not call this a 5-competitor audit.')
        (folder/'Opportunity_Report.md').write_text('\n'.join(report),encoding='utf-8')
    buyer=base/'Etsy_Buyer_Download.zip';seller=base/'Etsy_Full_Seller_Launch.zip'
    make_zip(root/'02_Buyer_Downloads',buyer)
    make_zip(root,seller,exclude_dirs=('_previews',))
    for p in (buyer,seller):
        if not p.stat().st_size:raise RuntimeError(f'Empty deliverable: {p}')
    return qa,buyer,seller
