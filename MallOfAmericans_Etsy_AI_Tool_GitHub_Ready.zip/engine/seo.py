"""SEO fallback is explicitly editorial draft, NOT verification of Etsy demand."""
import csv
import json
from pathlib import Path

PET_TAGS=['pet sitter planner','multi pet care','pet sitting forms','dog sitter notes','cat sitter checklist','pet handoff kit',
          'pet feeding chart','pet care binder','pet visit log','pet emergency info','pet instructions','pet sitter printable','vacation pet planner']

def clean_tags(tags):
    if len(tags)!=13 or any(not t.strip() or len(t)>20 for t in tags) or len({t.casefold() for t in tags})!=13:
        raise ValueError('Etsy requires exactly 13 distinct nonblank tags, each <=20 characters in this workflow')
    return tags


def draft_seo(bp,price=12.95):
    name=bp['name'];n=len(bp['pages'])
    if 'Pet Sitter' in name or 'Pet ' in name:
        tags=PET_TAGS
    else:
        base=['printable planner','digital organizer','instant download','US letter printable','fillable pdf','checklist template',
              'home organization','daily tracker','planning pages','printable workbook','organization kit','digital template','editable pdf']
        tags=base
    tags=clean_tags(tags)
    needs='; '.join(bp.get('benefits',[])[:3])
    return {'title':f'{name} | Printable & Fillable PDF | US Letter Organizer',
            'alternatives':[f'{name} | Digital Download Checklist & Logs',f'Printable {name} | Fillable Planning Kit'],
            'tags':tags,
            'description':f'''{name.upper()} — PRINTABLE & FILLABLE DIGITAL DOWNLOAD

Plan confidently with a focused set of practical templates. This download is designed for {bp.get('buyer','US households')}.

WHAT THIS KIT HELPS WITH
{chr(10).join('- '+x for x in bp.get('benefits',[])[:5])}

WHAT YOU RECEIVE
• 1 US Letter printable PDF ({n} pages; 8.5 × 11 inches)
• 1 US Letter fillable PDF ({n} pages; actual interactive text fields)
• READ_ME_FIRST instructions

HOW TO USE
1. Download after Etsy purchase.
2. Open the printable PDF to print on US Letter paper at 100%, OR open the fillable PDF in a compatible desktop PDF viewer.
3. Fill in your own real details. Save a copy and share only with authorized people.

IMPORTANT
This is a DIGITAL product, not a physical shipment. No printed pages or accessories will arrive by mail. Some mobile PDF previews may not save form data; use a compatible desktop PDF application when filling digital fields. Colors can vary by display/printer.

{bp.get('disclaimer','Organizational use only; not professional advice.')}

{needs}

Thank you for supporting MallOfAmericans!''',
            'primary_keywords':[name.lower()],
            'secondary_keywords':['fillable pdf','us letter printable','digital download'],
            'category_suggestion':'Digital Prints / Templates — confirm closest available Etsy category in listing UI',
            'alt_text':[f'{name}, actual printable digital download preview {j+1}' for j in range(10)],
            'price_usd':float(price),
            'evidence_notes':'Editorial draft only. Tags and demand NOT verified by any seller-only data; review actual search results before publishing.'}


def write_seo(seo, out_dir):
    d=Path(out_dir);d.mkdir(parents=True,exist_ok=True)
    tags=clean_tags(seo['tags'])
    price=float(seo.get('price_usd',0))
    if price<=6:raise ValueError('Asking price must be strictly above US $6')
    (d/'Etsy_Listing_Copy.md').write_text('\n'.join([
        '# Etsy Listing Copy (Review before publishing)',
        f"**Suggested price:** ${price:.2f}",f"**Title:** {seo.get('title','')}",
        '## Alternative titles','\n'.join('- '+x for x in seo.get('alternatives',[])),
        '## Description',seo['description'],'## 13 tags',', '.join(tags),
        '## Category',seo.get('category_suggestion','Review in Etsy UI'),
        '## Keywords',', '.join(seo.get('primary_keywords',[])+seo.get('secondary_keywords',[])),
        '## Evidence notes',seo.get('evidence_notes','Not independently verified')]),encoding='utf-8')
    with (d/'13_Tags.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.writer(f);writer.writerow(['tag']);writer.writerows([[tag] for tag in tags])
    (d/'SEO_Data.json').write_text(json.dumps(seo,indent=2,ensure_ascii=False),encoding='utf-8')
    return d
