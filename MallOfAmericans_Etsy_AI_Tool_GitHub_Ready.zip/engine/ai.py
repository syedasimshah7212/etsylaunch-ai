"""Optional Anthropic/Claude client: strictly structured original pages + SEO.
Use validated public context; never invent competitor revenue or quote unseen text.
"""
import json
import re


def call_claude(api_key, instruction, payload, model='claude-sonnet-4-5'):
    if not api_key:
        raise ValueError('ANTHROPIC_API_KEY is required for AI customization. Use a built-in template otherwise.')
    import anthropic
    client=anthropic.Anthropic(api_key=api_key,timeout=95.0,max_retries=1)
    prompt=("Return ONLY a valid JSON object, without Markdown fences. No invented market facts or citations. "
            +instruction+"\nInput data:\n"+json.dumps(payload,ensure_ascii=False)[:24500])
    reply=client.messages.create(model=model,max_tokens=7500,temperature=0.35,
                                 system="You are an original, careful US digital-product editor, Etsy copywriter and layout planner. Never copy competitors. Produce practical, useful content with accurate limits.",
                                 messages=[{"role":"user","content":prompt}])
    raw=''.join(b.text for b in reply.content if getattr(b,'type','')=='text').strip()
    raw=re.sub(r'^```(?:json)?\s*|\s*```$', '',raw).strip()
    return json.loads(raw)


def generate_blueprint(api_key, product_name, buyer, references=None):
    instruction='''Generate an ORIGINAL substantial, useful U.S. Letter printable/fillable 12–18-page DIGITAL PRODUCT, not a generic empty notebook. JSON schema exactly:
{"name":str,"subtitle":str,"buyer":str,"benefits":[str,str,str],"pages":[{"title":str,"intro":str,"sections":[{"heading":str,"guidance":str,"fields":[str,str,str,str]}]}],"disclaimer":str}
Ensure 12–18 pages, 2 sections per page, 3–5 SPECIFIC, REAL-WORLD fillable fields in each section; instructions must be safely actionable. All fields UNIQUE per page and tightly relevant; user-directed original content. Avoid medical/legal/financial advice, guarantees, fake claims. Exclude private information collection requirements unless relevant. No claims about compatibility not actually tested.'''
    return call_claude(api_key,instruction,{"product":product_name,"buyer":buyer,"research_results":references or []})


def generate_seo(api_key, blueprint, competitors):
    instruction='''Return ONLY valid JSON object with {"title":str,"alternatives":[str,str],"tags":[13 DIFFERENT str each at most 20 characters],"description":str,"primary_keywords":[str],"secondary_keywords":[str],"category_suggestion":str,"alt_text":[10 str],"price_usd":float,"evidence_notes":str}. Product is actual US Letter print+fillable PDFs. Describe only evidenced features and contents from blueprint. Use useful natural US buyer English, avoid competitor copying, unsupported search volume/sales statements. Full asking price strictly >$6. Make SEO clear, no stuffing. Explicitly state DIGITAL DOWNLOAD, no physical shipment, printing/writing vs fillable PDF use. Notes must distinguish unverified signals, seller-only tags unseen. Never claim Etsy policy compliance is guaranteed.'''
    return call_claude(api_key,instruction,{"product":blueprint,"verified_competitor_public_data":competitors})
