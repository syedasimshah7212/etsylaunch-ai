"""Etsy opportunity discovery using attributable, public search-result evidence.
No inferred revenue, listing sales or private tags. No circumvention of Etsy controls.
"""
from __future__ import annotations
from datetime import datetime, timezone
import re
import requests
from urllib.parse import urlparse

IDEAS = [
    ("Multi-Pet Sitter Handoff Kit", "pet sitter instructions multi pet printable", "Traveling pet owners coordinating multiple caregivers"),
    ("Senior Pet Care Coordination Binder", "senior dog care tracker printable", "Owners coordinating senior pet care among family and sitters"),
    ("Home Repair Warranty Organizer", "home appliance warranty tracker printable", "Homeowners managing warranty claims and service visits"),
    ("Short-Term Rental Turnover Checklist", "vacation rental turnover checklist template", "Independent US short-term rental hosts"),
    ("After-School Pickup Authorization Planner", "school pickup authorization planner printable", "Parents coordinating changing pickup contacts"),
    ("Family Emergency Go-Bag Checklist Bundle", "family emergency go bag checklist printable", "Households preparing for evacuation and power outages"),
    ("Move-Out Deposit Evidence Binder", "rental move out inspection printable", "Renters documenting deposit conditions and handovers"),
    ("New Puppy Household Care Rotation Kit", "puppy care schedule printable family", "Households coordinating puppy responsibilities"),
    ("Small Venue Event Vendor Handoff Book", "event vendor contact timeline template", "DIY US event organizers with several suppliers"),
    ("Caregiver Shift Handoff Organizer", "caregiver daily shift handoff printable", "Families coordinating non-medical home-care routines"),
]
WEIGHTS = {"buyer_pain":.25,"demand_evidence":.25,"competition_gap":.20,"price_justification":.15,"feasibility":.10,"brand_fit":.05}


def today():
    return datetime.now(timezone.utc).date().isoformat()


def brave_search(query: str, api_key: str, count=10):
    if not api_key:
        return []
    res=requests.get("https://api.search.brave.com/res/v1/web/search",params={"q":query,"count":count,"country":"us","search_lang":"en"},headers={"X-Subscription-Token":api_key,"Accept":"application/json"},timeout=22)
    res.raise_for_status()
    obj=res.json()
    rows=[]
    for hit in obj.get('web',{}).get('results',[]):
        link=hit.get('url','')
        if link.startswith('https://'):
            rows.append({"title":hit.get('title',''),"url":link,"snippet":re.sub('<[^>]+>','',hit.get('description','')),"checked":today(),"source_type":"public search result"})
    return rows


def is_etsy_listing(url):
    try:
        parsed=urlparse(url)
        host=(parsed.hostname or '').lower()
        return parsed.scheme=='https' and (host=='etsy.com' or host.endswith('.etsy.com')) and '/listing/' in parsed.path
    except ValueError:
        return False


def safe_score(r):
    """Heuristics cannot establish market demand. Use observed competitor count ONLY as evidence availability."""
    evidence_count=len(r.get('sources',[]))
    # Directional priors; demand gap remains UNKNOWN unless corroborated data exists.
    heuristic={"buyer_pain":4,"demand_evidence":1 if evidence_count==0 else min(3,evidence_count),"competition_gap":2,
               "price_justification":4,"feasibility":4,"brand_fit":4}
    score=sum(heuristic[k]*v for k,v in WEIGHTS.items())
    return round(score,2),heuristic


def research_ideas(api_key='', max_calls=10):
    results=[]
    for idx,(name,q,buyer) in enumerate(IDEAS):
        sources=[]
        if api_key and idx<max_calls:
            try:
                sources=brave_search('site:etsy.com/listing/ '+q,api_key,8)
            except requests.RequestException as exc:
                sources=[]
        row={"name":name,"query":q,"buyer":buyer,"sources":[s for s in sources if is_etsy_listing(s['url'])],
             "evidence_status":"SEARCH RESULTS ONLY" if sources else "UNVERIFIED – no live search results", "date":today()}
        row['weighted_score'],row['heuristic_inputs']=safe_score(row)
        results.append(row)
    return sorted(results,key=lambda x:x['weighted_score'],reverse=True)


def find_competitors(query,api_key='',manual_urls=None):
    records=[]
    for url in (manual_urls or []):
        if is_etsy_listing(url):
            records.append({"title":"Manual URL – inspect in browser", "url":url,"snippet":"Public listing description not independently verified; user-provided link.","checked":today(),"source_type":"user-provided URL"})
    if api_key:
        try:
            records+= [r for r in brave_search('site:etsy.com/listing/ '+query,api_key,15) if is_etsy_listing(r['url'])]
        except requests.RequestException as exc:
            records.append({"title":"SEARCH ERROR","url":"","snippet":str(exc),"checked":today(),"source_type":"error"})
    seen=set(); unique=[]
    for item in records:
        url=item['url'].split('?')[0]
        if url and url not in seen:
            seen.add(url); unique.append(item)
    return unique[:5]
