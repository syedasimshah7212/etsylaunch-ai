"""Actual US-Letter printable + interactive PDF product generator, from a content blueprint."""
from __future__ import annotations
from pathlib import Path
import json
import re
import textwrap
import fitz
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color
from reportlab.lib.utils import simpleSplit

PW,PH=612,792  # actual US Letter in points
NAVY=HexColor('#253744'); TEAL=HexColor('#2B756E'); LIGHT=HexColor('#EAF3F0'); BODY=HexColor('#435561'); BORDER=HexColor('#CDDCD8')


def validate_blueprint(bp):
    if not isinstance(bp,dict) or not isinstance(bp.get('pages'),list) or not bp.get('name'):
        raise ValueError('Blueprint requires name and pages.')
    if len(bp['pages'])<2 or len(bp['pages'])>40:
        raise ValueError('Blueprint must have between 2 and 40 finished pages.')
    for i,p in enumerate(bp['pages']):
        if not p.get('title') or not p.get('sections'):
            raise ValueError(f'Page {i+1} lacks title or sections.')
        for section in p['sections']:
            if not section.get('heading') or not section.get('fields'):
                raise ValueError(f'Page {i+1} has a blank heading or empty fields.')
            if len(section['fields'])>6:
                raise ValueError('Limit each section to 6 fields so everything fits legibly.')
    return bp


def _text(c,text,x,y,max_width,size=10,bold=False,maxlines=4,leading=15):
    c.setFont('Helvetica-Bold' if bold else 'Helvetica',size)
    lines=simpleSplit(str(text),'Helvetica-Bold' if bold else 'Helvetica',size,max_width)[:maxlines]
    for t in lines:
        c.drawString(x,y,t)
        y-=leading
    return y


def draw_sheet(c,page,index,total,fillable):
    c.setFillColor(NAVY);c.rect(0,PH-114,PW,114,stroke=0,fill=1)
    c.setFillColor(HexColor('#B8D9D5'));c.setFont('Helvetica-Bold',9)
    c.drawString(43,PH-43,'MALLOFAMERICANS  /  HOME & PET ORGANIZATION')
    c.setFillColor(HexColor('#FFFFFF'))
    _text(c,page['title'].upper(),43,PH-79,525,17,True,2,20)
    c.setFillColor(BODY)
    _text(c,page.get('intro',''),43,PH-143,520,10,False,2,15)
    n_sections=len(page['sections'])
    if n_sections>3: raise ValueError('Each page should have at most 3 sections for legibility.')
    usable_top=PH-190; usable_bottom=84
    card_h=(usable_top-usable_bottom - 18*(n_sections-1))/n_sections
    field_count=0
    for si,section in enumerate(page['sections']):
        top=usable_top-si*(card_h+18)
        bot=top-card_h
        c.setFillColor(HexColor('#F7FAF9'));c.setStrokeColor(BORDER)
        c.roundRect(39,bot,PW-78,card_h,12,stroke=1,fill=1)
        c.setFillColor(TEAL)
        _text(c,section['heading'],57,top-29,480,12,True,1)
        c.setFillColor(BODY)
        gy=_text(c,section.get('guidance',''),57,top-51,480,8.5,False,2,13)-7
        fields=section['fields']
        if len(fields)>6:raise ValueError('Too many fields')
        room=(gy-(bot+23))/len(fields)
        if room<32:raise ValueError(f"Too many / too long fields for {page['title']}")
        for fi,label in enumerate(fields):
            yy=gy-fi*room
            c.setFillColor(NAVY)
            _text(c,label,58,yy,440,8.1,True,1)
            input_y=yy-22
            c.setFillColor(HexColor('#FFFFFF'));c.setStrokeColor(BORDER)
            c.roundRect(56,input_y-9,500,20,4,stroke=1,fill=1)
            if fillable:
                # Form fields are true AcroForm widgets, not just painted boxes.
                c.acroForm.textfield(name=f'p{index+1:02d}s{si+1}f{fi+1}',tooltip=str(label),
                       x=59,y=input_y-6,width=493,height=17,
                       borderWidth=0,forceBorder=False,
                       textColor=NAVY,fillColor=Color(1,1,1),fontName='Helvetica',fontSize=9)
                field_count+=1
    c.setStrokeColor(BORDER);c.line(41,57,PW-41,57)
    c.setFillColor(BODY);c.setFont('Helvetica',8)
    c.drawString(42,42,'Digital download • Private caregiver notes • Keep this document secure')
    c.drawRightString(PW-42,42,f'{index+1} / {total}')
    c.showPage()
    return field_count


def build_product(bp, out_dir):
    bp=validate_blueprint(bp)
    folder=Path(out_dir);folder.mkdir(parents=True,exist_ok=True)
    label=re.sub(r'[^a-zA-Z0-9]+','_',bp['name']).strip('_')[:58]
    print_pdf=folder/f'{label}_Printable.pdf'
    fill_pdf=folder/f'{label}_Fillable.pdf'
    field_total=0
    for fillable,path in [(False,print_pdf),(True,fill_pdf)]:
        c=canvas.Canvas(str(path),pagesize=(PW,PH),pageCompression=1)
        c.setTitle(bp['name']+(' (Fillable)' if fillable else ' (Printable)'))
        c.setAuthor('MallOfAmericans')
        fields=0
        for i,p in enumerate(bp['pages']):
            fields+=draw_sheet(c,p,i,len(bp['pages']),fillable)
        c.save()
        if fillable:field_total=fields
    readme=folder/'READ_ME_FIRST.txt'
    readme.write_text(f"{bp['name']}\n\nDIGITAL DOWNLOAD. No physical item is shipped.\n"
        "WHAT'S INCLUDED\n- Printable PDF (US Letter, 8.5 x 11 inches)\n- Fillable PDF (US Letter, 8.5 x 11 inches)\n"
        "INSTRUCTIONS\n1. Print at 100% on US Letter paper, or open the fillable PDF in a compatible desktop PDF reader.\n"
        "2. Save a local copy, type into the fields, and save again. Some mobile preview apps do not preserve filled forms.\n"
        "3. Duplicate / print blank pages as needed. Keep completed personal details secure; share only with approved caregivers.\n"
        f"\n{bp.get('disclaimer','This resource is for personal organization, not professional advice.')}\n"
        "Personal-use license: You may use completed copies for your own household; do not resell, distribute or republish the template.\n",
        encoding='utf-8')
    meta={"name":bp['name'],"pages":len(bp['pages']),"fillable_fields":field_total,
          "files":[p.name for p in [print_pdf,fill_pdf,readme]],"paper_size":"US Letter 8.5 × 11 in"}
    (folder/'PRODUCT_DETAILS.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    for path in [print_pdf,fill_pdf]:
        with fitz.open(path) as pdf:
            if len(pdf)!=len(bp['pages']):raise RuntimeError(f'PDF page count incorrect: {path}')
            if not all(page.rect.width==612 and page.rect.height==792 for page in pdf):
                raise RuntimeError('Wrong paper size')
            if path==fill_pdf:
                actual=sum(1 for pg in pdf for _ in (pg.widgets() or []))
                if actual!=field_total:raise RuntimeError(f'Expected {field_total} PDF form widgets, found {actual}')
    return meta


def create_previews(pdf_path,preview_dir,max_pages=10):
    folder=Path(preview_dir);folder.mkdir(parents=True,exist_ok=True)
    items=[]
    with fitz.open(pdf_path) as pdf:
        for idx in range(min(max_pages,len(pdf))):
            pix=pdf[idx].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False)
            path=folder/f'page_{idx+1:02d}.png'
            pix.save(str(path));items.append(path)
    return items
