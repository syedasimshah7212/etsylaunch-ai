import json
from pathlib import Path
rows=[
('Caregiver Quick Start','Give each caregiver one reliable place to begin.',[
 ('At a glance','Review these before the first visit.',['Pet names and head count','Owner preferred phone and text number','Primary sitter and dates','Approved backup caregiver']),
 ('Start-of-visit routine','Use the same safety sequence each time.',['Entry method shared separately','Pet count upon entering','Secure gate and door check','Urgent notes and restrictions'])]),
('Contacts & Emergency Protocol','Make escalation steps clear before an emergency.',[
 ('People to call','Do not share this sheet beyond approved caregivers.',['Owner primary contact and hours','Secondary emergency contact','Neighbor or local helper','Emergency veterinary clinic and phone']),
 ('Decision tree','Written caregiver boundaries reduce misunderstandings.',['When to call owner immediately','What to do if owner is unreachable','How to transport a pet if authorized','Location of carriers and records'])]),
('Pet Profiles: Individual Needs','Use one copy per pet and keep completed copies together.',[
 ('Identification','Care should be tailored to each animal.',['Pet name, species and age','Photo or identifying marks','Microchip or collar information if desired','Temperament and handling needs']),
 ('Daily care','Do not infer instructions from another pet.',['Diet and portions, owner provided','Approved treats and prohibited foods','Routine and sleep locations','Signs the pet needs extra attention'])]),
('Feeding Schedule Matrix','Avoid duplicate meals and inconsistent routines.',[
 ('Meals','Write exact times and amounts for each pet.',['Pet names and food locations','Morning meal time and amount','Evening meal time and amount','Water refresh schedule']),
 ('Checks','Record completed care, not guesses.',['Feeding confirmation and initials','Food refusal or appetite changes','Special diet instructions','Supplies running low'])]),
('Walking, Play & Enrichment','Plan realistic routine windows and safety precautions.',[
 ('Activity plan','Specify what is safe for each pet.',['Pet and approved activities','Preferred walk or play times','Equipment and leash locations','Weather or household restrictions']),
 ('Daily observation','Capture useful non-medical context.',['Bathroom or litter routine','Energy and temperament','Challenges noticed','Owner update time'])]),
('Medication Instruction Transfer','Record owner/vet-provided instructions only; no advice.',[
 ('Written directions','Verify instructions with owner before administering anything.',['Pet name and medication label','Dose exactly as owner/vet directed','Administration time and method','Storage and refill location']),
 ('Documentation','Never guess, double doses, or change a prescription.',['Date and time given / skipped','Caregiver initials','Problem encountered and owner notified','Next required dose per instructions'])]),
('Home Safety & Access','Reduce preventable access and household issues.',[
 ('At entry','Store security details in a secure handoff channel.',['Key or lockbox transfer status','Alarm instructions shared securely','Rooms and gates to keep closed','Pets who may escape when entering']),
 ('At exit','Complete a final pass every visit.',['Pets all accounted for','Doors, windows and gates locked','Lights and thermostat per instructions','Home issue flagged to owner'])]),
('Daily Visit Completion Log','Use a fresh copy for each scheduled visit.',[
 ('Visit record','Write actual completion times.',['Date, arrival and departure','Caregiver name and planned pets','Feeding / water / litter / walk tasks','Medication log checked if applicable']),
 ('Handoff notes','Keep unresolved issues visible.',['Behavior or appetite observations','Photo or message sent with permission','Tasks needing owner response','Next visit time and assigned sitter'])]),
('Caregiver Shift Handoff','Protect continuity when more than one person helps.',[
 ('Outgoing caregiver','Document work completed and pending.',['Outgoing sitter and finish time','All pets confirmed present','Unfinished tasks and reason','Supplies or safety warnings']),
 ('Incoming caregiver','Have the next person acknowledge the plan.',['Incoming sitter and handoff time','Tasks received / questions','Next required care visit','Owner notified of the transition'])]),
('Backup Coverage Plan','Have a fallback before travel begins.',[
 ('Backups','Confirm availability in advance.',['First backup / number','Second backup / number','Conditions that trigger backup plan','How to transfer access safely']),
 ('Activation','A backup is active only once confirmed.',['Activation date and time','Person accepting coverage','Next assigned visit and required tasks','Owner confirmation or update sent'])]),
('Return-Home Summary','Make return day smooth and clarify follow-up.',[
 ('Pet handback','Keep owner informed of any change.',['Last care time and tasks','Appetite or behavior notes','Any incidents and steps taken','Items to ask veterinarian about']),
 ('Household handback','Close the operational loop.',['Keys or access returned','Remaining supplies / purchases','Home cleanup or maintenance notes','Final sitter signature and date'])]),
('Fridge Quick Reference','Leave this with approved caregivers only.',[
 ('Immediate actions','This is a summary; keep the full kit accessible.',['All pet names and count','Owner and sitter contact','Next scheduled task and time','Emergency vet phone']),
 ('Safety reminders','Fill in details based on the actual home.',['Door and gate precautions','Feeding and medication sheet location','Carrier / leash / litter locations','When to escalate and who to call'])]),
]
obj={"name":"Multi-Pet Sitter Handoff Kit","subtitle":"Printable & Fillable Pet Care Instructions and Visit Logs","buyer":"US households coordinating care for multiple pets","benefits":["Organize every pet's routine","Give caregivers clear handoff instructions","Record daily care and visit completion"],"disclaimer":"For organization only. Follow owner and veterinarian instructions; this kit does not provide medical guidance.","pages":[{"title":title,"intro":intro,"sections":[{"heading":sec[0],"guidance":sec[1],"fields":sec[2]} for sec in sect]} for title,intro,sect in rows]}
path=Path(__file__).resolve().parent.parent/'templates/pet_sitter.json'
path.write_text(json.dumps(obj,indent=2),encoding='utf-8')
print(path,len(obj['pages']))
