#!/usr/bin/env python3
"""Generate 10 actual Etsy JPG mockups and 2 silent 15s MP4 videos.

Inputs MUST be truthful images of the FINISHED product, not invented samples.
Requirements: Pillow, ffmpeg, ffprobe.
"""
import argparse
import json
import math
import shutil
import subprocess
import tempfile
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H = 2400, 1800
KINDS = [
    ('01_hero.jpg', 'Bring order to your day', 'See the real product'),
    ('02_whats_included.jpg', 'See what is included', 'A closer look inside'),
    ('03_benefit.jpg', 'Make the next step easier', 'Designed for practical use'),
    ('04_inside_pages.jpg', 'A look inside', 'Actual product pages'),
    ('05_workflow.jpg', 'Made to be useful', 'A clear path from plan to action'),
    ('06_format.jpg', 'Your digital resource', 'Check the delivered file details'),
    ('07_details.jpg', 'Thoughtful details', 'A closer look at the design'),
    ('08_lifestyle.jpg', 'A simple way to begin', 'A useful tool when you need it'),
    ('09_value.jpg', 'Everything in one place', 'Explore the actual content'),
    ('10_final_details.jpg', 'Ready to explore?', 'Digital delivery — no physical item'),
]
PALETTES = [
    ((248,244,238),(29,49,64),(222,129,98)),
    ((236,242,239),(28,65,57),(174,127,84)),
    ((251,240,230),(66,40,67),(183,110,127)),
    ((232,238,249),(38,58,101),(123,152,208)),
    ((248,244,220),(55,66,47),(183,140,60)),
    ((236,241,242),(42,52,69),(107,160,158)),
    ((249,237,240),(90,52,64),(197,121,103)),
    ((237,246,234),(50,75,54),(143,172,100)),
    ((245,243,253),(66,57,102),(139,120,196)),
    ((241,242,237),(52,55,66),(184,120,79)),
]


def font(size, bold=False):
    paths = ([
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf',
        '/Library/Fonts/Arial Bold.ttf',
    ] if bold else [
        '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
        '/Library/Fonts/Arial.ttf',
    ])
    for p in paths:
        if Path(p).exists():
            return ImageFont.truetype(p, size)
    return ImageFont.load_default(size=size)


def fit_lines(draw, text, max_px, f, max_lines=4):
    words = text.split()
    lines, current = [], ''
    for word in words:
        cand = (current + ' ' + word).strip()
        if draw.textbbox((0,0), cand, font=f)[2] <= max_px:
            current = cand
        else:
            if current: lines.append(current)
            current = word
    if current: lines.append(current)
    return lines[:max_lines]


def gradient(base, ink):
    img = Image.new('RGB', (W,H))
    d = ImageDraw.Draw(img)
    for y in range(H):
        p = y/H
        col = tuple(max(0,min(255,int(c - (p*12 if c>80 else p*2)))) for c in base)
        d.line([(0,y),(W,y)], fill=col)
    return img


def card(base, preview, x, y, w, h, angle=0):
    # Product-only preview cards; never rewrite/mutate the pictured content.
    sh = Image.new('RGBA',(w+70,h+70),(0,0,0,0))
    ds=ImageDraw.Draw(sh)
    ds.rounded_rectangle((34,30,w+34,h+30),radius=42,fill=(0,0,0,45))
    sh=sh.filter(ImageFilter.GaussianBlur(28))
    bg=Image.new('RGBA',(w,h),(255,255,255,255))
    ImageDraw.Draw(bg).rounded_rectangle((0,0,w-1,h-1),radius=30,outline=(215,211,206,255),width=4)
    tmp=preview.copy().convert('RGB')
    tmp.thumbnail((w-70,h-70),Image.Resampling.LANCZOS)
    bg.paste(tmp,((w-tmp.width)//2,(h-tmp.height)//2))
    layer=Image.new('RGBA',(w+70,h+70),(0,0,0,0))
    layer.alpha_composite(sh)
    layer.alpha_composite(bg,(24,16))
    if angle:
        layer=layer.rotate(angle,expand=True,resample=Image.Resampling.BICUBIC)
    base.paste(layer,(int(x),int(y)),layer)


def render_mockup(index, name, default_head, default_sub, previews, title, subtitle, features, out):
    bg, ink, accent = PALETTES[index]
    canvas=gradient(bg, ink).convert('RGBA')
    d=ImageDraw.Draw(canvas)
    # Composed visual decoration (not a misleading photo or fake sale badge).
    d.ellipse((1750,-600,3150,770),fill=accent+(34,))
    d.ellipse((-580,1720,300,2600),fill=ink+(15,))
    d.rounded_rectangle((82,82,2318,1718),radius=36,outline=ink+(34,),width=3)
    small=font(40,True); label=font(39,False)
    d.text((165,148),'MALLOFAMERICANS  /  DIGITAL DOWNLOAD',font=small,fill=ink)
    d.line((165,222,2230,222),fill=ink+(65,),width=2)
    # Show actual product name on every mockup without clipping.
    hero = title if index == 0 else default_head
    sub = subtitle if index == 0 else default_sub
    text_x = 175 if index % 3 != 1 else 1320
    text_width = 975 if text_x == 175 else 915
    page_x = 1320 if text_x == 175 else 150
    fh=font(110 if index==0 else 105,True)
    lines=fit_lines(d,hero,text_width,fh,4)
    yy=358
    for li in lines:
        d.text((text_x,yy),li,font=fh,fill=ink)
        yy+=137
    fs=font(51)
    for li in fit_lines(d,sub,text_width,fs,3):
        d.text((text_x,yy+25),li,font=fs,fill=ink)
        yy+=71
    if features:
        d.rounded_rectangle((text_x, min(yy+78,1215), text_x+min(text_width,980),min(yy+178,1315)),radius=27,fill=accent+(46,))
        d.text((text_x+25,min(yy+98,1235)),features[index % len(features)][:42],font=font(43,True),fill=ink)
    # Meaningfully vary photo count, location, depth, and angle across images.
    primary=previews[index % len(previews)]
    secondary=previews[(index+1) % len(previews)]
    if index in [1,3,8] and len(previews)>1:
        card(canvas,secondary,page_x+230,485,720,900,7)
        card(canvas,primary,page_x+30,370,760,985,-5)
    elif index in [4,6,7] and len(previews)>1:
        card(canvas,secondary,page_x+120,555,790,875,-7)
        card(canvas,primary,page_x+10,322,770,880,5)
    else:
        card(canvas,primary,page_x+55,305,825,1120,-3 if index%2==0 else 4)
    d=ImageDraw.Draw(canvas)
    d.line((164,1578,2245,1578),fill=ink+(55,),width=2)
    d.text((165,1610),'PREVIEW OF ACTUAL INCLUDED CONTENT',font=font(32,True),fill=ink)
    d.text((1795,1610),f'{index+1:02d} / 10',font=font(37,True),fill=ink)
    canvas.convert('RGB').save(out/name,'JPEG',quality=94,subsampling=0,optimize=True)


def media_duration(path):
    run=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nokey=1:noprint_wrappers=1',str(path)],capture_output=True,text=True,check=True)
    return float(run.stdout.strip())


def video_from_images(images, out):
    # Four true product images, 3.75 sec each; silent full 15-second MP4.
    with tempfile.TemporaryDirectory(prefix='etsy_segments_') as tmp:
        temp=Path(tmp)
        clips=[]
        for j,p in enumerate(images):
            segment=temp/f'segment_{j:02d}.mp4'
            vf=("scale=1200:900:flags=lanczos,"
                "pad=1200:1200:(ow-iw)/2:(oh-ih)/2:color=0xf5f3ee,"
                "zoompan=z='min(zoom+0.0008,1.08)':x='iw/2-(iw/zoom/2)':"
                "y='ih/2-(ih/zoom/2)':d=90:fps=24:s=1080x1080,"
                "format=yuv420p,fade=t=in:st=0:d=0.2,fade=t=out:st=3.5:d=0.25")
            cmd=['ffmpeg','-loglevel','error','-y','-loop','1','-i',str(p),'-vf',vf,'-frames:v','90',
                 '-c:v','libx264','-preset','ultrafast','-crf','24','-pix_fmt','yuv420p','-an',str(segment)]
            subprocess.run(cmd,check=True)
            clips.append(segment)
        concat=temp/'parts.txt'
        concat.write_text(''.join("file '"+str(p).replace("'", "'\\''")+"'\n" for p in clips),encoding='utf-8')
        subprocess.run(['ffmpeg','-loglevel','error','-y','-f','concat','-safe','0','-i',str(concat),'-c','copy','-an',str(out)],check=True)
        dur=media_duration(out)
        if not (14.9 <= dur <= 15.1):
            raise RuntimeError(f'Unexpected video duration: {dur:.3f}s for {out}')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--preview-dir',type=Path,required=True,help='PNG/JPEG renders of REAL finished buyer product pages')
    ap.add_argument('--output-dir',type=Path,required=True)
    ap.add_argument('--title',required=True)
    ap.add_argument('--subtitle',default='Original, practical digital resource')
    ap.add_argument('--features',default='',help='Use vertical bars to separate 1–4 truthful features')
    ap.add_argument('--labels-json',type=Path,help='optional file of 10 accurate [headline,subheading] pairs')
    ap.add_argument('--skip-videos',action='store_true',help='Make 10 JPGs only; QA will mark 2 MP4s missing')
    args=ap.parse_args()
    global KINDS
    if args.labels_json:
        labels=json.loads(args.labels_json.read_text(encoding='utf-8'))
        if len(labels)!=10 or any(len(x)!=2 for x in labels):
            raise SystemExit('labels JSON must hold ten 2-string [headline,subtitle] pairs')
        KINDS=[(KINDS[i][0],str(labels[i][0]),str(labels[i][1])) for i in range(10)]
    if not args.skip_videos and (shutil.which('ffmpeg') is None or shutil.which('ffprobe') is None):
        raise SystemExit('ffmpeg + ffprobe required for actual MP4 production')
    inputs=sorted(p for p in args.preview_dir.glob('*') if p.suffix.lower() in ('.jpg','.jpeg','.png','.webp'))
    if not inputs:
        raise SystemExit('No real product preview images supplied: do not fabricate product pages.')
    previews=[]
    for p in inputs:
        with Image.open(p) as im:
            previews.append(im.convert('RGB').copy())
    images_dir=args.output_dir/'03_Etsy_Mockups'
    videos_dir=args.output_dir/'04_Etsy_Videos'
    images_dir.mkdir(parents=True,exist_ok=True)
    videos_dir.mkdir(parents=True,exist_ok=True)
    features=[x.strip() for x in args.features.split('|') if x.strip()]
    for i,(name,head,sub) in enumerate(KINDS):
        render_mockup(i,name,head,sub,previews,args.title,args.subtitle,features,images_dir)
    if not args.skip_videos:
        video_from_images([images_dir/KINDS[i][0] for i in [0,1,3,9]],videos_dir/'01_product_overview.mp4')
        video_from_images([images_dir/KINDS[i][0] for i in [3,4,6,8]],videos_dir/'02_inside_the_product.mp4')
    print('CREATED 10 JPG mockups:',images_dir)
    print('CREATED 2 actual 15-second MP4 videos:',videos_dir)
    for mp4 in sorted(videos_dir.glob('*.mp4')):
        print(mp4.name,'duration:',f'{media_duration(mp4):.3f}s')

if __name__=='__main__':
    main()
