import json
from pathlib import Path
import fitz
from engine.product import build_product
from engine.seo import clean_tags, draft_seo
from engine.research import is_etsy_listing, research_ideas
from engine.package import check_assets

ROOT=Path(__file__).resolve().parents[1]


def bp():return json.loads((ROOT/'templates/pet_sitter.json').read_text(encoding='utf-8'))


def test_original_pdf_build_and_forms(tmp_path):
    meta=build_product(bp(),tmp_path/'buyer')
    assert meta['pages']==12
    assert meta['fillable_fields']==96
    with fitz.open(tmp_path/'buyer'/meta['files'][0]) as pdf:
        assert len(pdf)==12
        assert pdf[0].rect.width==612
        assert 'CAREGIVER QUICK START' in pdf[0].get_text()
    with fitz.open(tmp_path/'buyer'/meta['files'][1]) as pdf:
        assert sum(1 for page in pdf for _ in page.widgets() or [])==96


def test_seo_valid_tags():
    seo=draft_seo(bp())
    assert len(clean_tags(seo['tags']))==13
    assert seo['price_usd']>6


def test_research_without_key_labels_unverified():
    ideas=research_ideas('')
    assert len(ideas)==10
    assert all('UNVERIFIED' in r['evidence_status'] for r in ideas)


def test_etsy_url_filter():
    assert is_etsy_listing('https://www.etsy.com/listing/1234/sample')
    assert not is_etsy_listing('https://evil-etsy.com/listing/1234/sample')
    assert not is_etsy_listing('https://www.etsy.com/shop/test')


def test_missing_media_is_detected(tmp_path):
    meta=build_product(bp(),tmp_path/'02_Buyer_Downloads')
    qa=check_assets(tmp_path,meta)
    assert not qa['complete'] and len(qa['issues'])==12
